/*
 * CSCI 200 - Spring 2026
 * A2 - Automated Teller Machine
 * Student: Austin Haas
 * Description: Just the main function for the programmm
 * 
 */

#include <iostream>
#include "atmFunctions.h"
using namespace std;

int main() {
    boot_machine();
    return 0;
}
