/* CSCI200 Green Eggs and Ham Using Classes
 *
 * This program reads in a text file and parses the contents to count word data.
 *
 * Copyright 2026 Dr. Jeffrey Paone
 */

Your task is to implement the functions and classes such that provided main() generates the expected output as shown in the solutions folder.
