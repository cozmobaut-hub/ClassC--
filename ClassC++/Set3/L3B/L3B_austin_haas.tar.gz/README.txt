/* CSCI200 Lab
 *
 * This program executes some tests that illustrate the properties
 * and behaviors of strings.
 *
 * Copyright 2026 Dr. Jeffrey Paone
 */

Your task is to implement the functions defined in string_functions.cpp such that all of the tests within the test suite pass.
