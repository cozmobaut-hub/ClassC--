#include <SFML/Graphics.hpp>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

using namespace std;

int main(int argc, char* argv[]) {
    string filename;

    if (argc > 1) {
        filename = argv[1];
    } else {
        cout << "Enter maze filename: ";
        cin >> filename;
    }

    ifstream fin(filename);
    if (!fin) {
        cerr << "Error: could not open file " << filename << "\n";
        return 1;
    }

    int R, C;
    fin >> R >> C;

    vector<vector<char>> maze(R, vector<char>(C));
    int startRow = -1, startCol = -1;

    for (int r = 0; r < R; r++) {
        for (int c = 0; c < C; c++) {
            fin >> maze[r][c];
            if (maze[r][c] == 'S') {
                startRow = r;
                startCol = c;
            }
        }
    }

    if (startRow == -1) {
        cerr << "Error: no start position found.\n";
        return 1;
    }

    sf::RenderWindow window(sf::VideoMode({static_cast<unsigned int>(15 * C),
                                           static_cast<unsigned int>(15 * R)}),
                            "Maze Visualizer");

    while (window.isOpen()) {
        while (const optional<sf::Event> event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>()) {
                window.close();
            }
        }

        window.clear();

        for (int r = 0; r < R; r++) {
            for (int c = 0; c < C; c++) {
                sf::RectangleShape cell(sf::Vector2f(15.f, 15.f));
                cell.setPosition(sf::Vector2f(static_cast<float>(c * 15),
                                              static_cast<float>(r * 15)));

                switch (maze[r][c]) {
                    case 'S':
                        cell.setFillColor(sf::Color::Green);
                        break;
                    case 'E':
                        cell.setFillColor(sf::Color::Red);
                        break;
                    case '#':
                        cell.setFillColor(sf::Color::Black);
                        break;
                    case '.':
                        cell.setFillColor(sf::Color::White);
                        break;
                }

                window.draw(cell);
            }
        }

        window.display();
    }

    return 0;
}
